/**
 * Tweeki-specific scripts
 */

/*
 var btn_index = document.querySelector('#btn-index');
 var btn_toolbox = document.querySelector('#btn-toolbox');

  function showUp()
 {
 	this.style.opacity = 1.0;
 }

 function jongBum()
 {
 	this.style.opacity = 0.15;
 }

 btn_index.showUp = showUp;
 btn_index.jongBum = jongBum;
 btn_toolbox.showUp = showUp;
 btn_toolbox.jongBum = jongBum;

 btn_index.onmouseover = btn_index.showUp();
 btn_toolbox.onmouseover = btn_toolbox.showUp();
 btn_index.onmouseout = btn_index.jongBum();
 btn_toolbox.onmouseout = btn_toolbox.jongBum();
*/


jQuery( function( $ )
{

	/**
	 * FOOTER
	 */
	// move sticky footer to bottom if the document is smaller than window
	function checkFooter()
	{
		if( $( '#footer.footer-sticky' ).length == 1 ) // only if footer is sticky
		{
			$( 'body' ).css( 'margin-bottom', 0 );
			// TODO: value shouldn't be hardcoded - use padding on #contentwrapper instead
			var minmargin = 50;
			var currentmargin = $( '#footer.footer-sticky' ).css( 'margin-top' );
			currentmargin = Number( currentmargin.replace( 'px', '' ) );
			var additionalmargin = $( window ).height() - $( 'body' ).height();
			var newmargin = Math.max( currentmargin + additionalmargin, minmargin );
			$( '#footer.footer-sticky' ).css( 'margin-top', newmargin + 'px' );
		}

	}

	// fade in initially hidden sticky footer
	checkFooter();
	$( '#footer.footer-sticky' ).animate( { opacity: 1 }, 1000 );

	// correct sticky footer on resize
	$(window).resize(function() {
		checkFooter();
	});

	// correct sticky footer on tab toggle
	$(document).on('shown.bs.tab', function (e) {
		checkFooter();
	});

	// correct bottom margin for body when fixed footer
	if( $( '#footer.footer-fixed' ).length == 1 )
	{
		var footerheight = $( '#footer' ).outerHeight();
		$( 'body' ).css( 'margin-bottom', footerheight );
	}






	/**
	 * LOGIN-EXT
	 */
	// don't close dropdown when clicking in the login form
	$( "#loginext" ).click( function( e ) {
    e.stopPropagation();
		});
	// focus user name field
	$( "#n-login-ext" ).click( function() {
			if( ! $( this ).parent().hasClass( "open" ) )
			{
				setTimeout( '$( "#wpName2" ).focus();', 100 );
			}
		});


	// DGIST WIKI scripts
	// Opacity change when mouse approach / move away
	$('#btn-index').mouseover( function() {
		$('#btn-index').css('opacity', 0.9);
	});

	$('#btn-index').mouseout( function() {
		$('#btn-index').css('opacity', 0.15);
	});

	$('#btn-toolbox').mouseover( function() {
		$('#btn-toolbox').css('opacity', 0.9);
	});

	$('#btn-toolbox').mouseout( function() {
		$('#btn-toolbox').css('opacity', 0.15);
	});


	// When click index button, show index panel
	$('#btn-index').click( function()
	{
	  $('#btn-index').css('display', 'none');
		$('#container-index-panel').css('display', 'block');
	});

	// When mouse comes over [Hide] button, show underline
	$('.hide-button').mouseover( function(event) {
		var target = $( event.target );
		target.css('text-decoration', 'underline');
	});

	$('.hide-button').mouseout( function(event) {
		var target = $( event.target );
		target.css('text-decoration', 'none');
	});

	// When click [ Hide ] button, close panels
	$('#index-hide-button').click( function() {
		$('#container-index-panel').css('display', 'none');
		$('#btn-index').css('display', 'block');
	});

	// When click toolbox button, show toolbox panel
	$('#btn-toolbox').click( function() {
		$('#btn-toolbox').css('display', 'none');
		$('#container-toolbox-panel').css('display', 'block');
	});

	$('#toolbox-hide-button').click( function() {
		$('#container-toolbox-panel').css('display', 'none');
		$('#btn-toolbox').css('display', 'block');
	})





	});
