/**
 * Tweeki-specific script to setup tooltips
 */

jQuery( function( $ ) {
			
	// initialize tooltips
	$(document).ready(function() {
  	$('[data-toggle="tooltip"]').tooltip()
	});
	
});
